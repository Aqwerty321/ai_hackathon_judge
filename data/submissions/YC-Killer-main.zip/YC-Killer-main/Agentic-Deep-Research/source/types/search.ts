export interface SearchItem {
  markdown: string;
  url: string;
}

export interface SearchData {
  data: SearchItem[];
}
